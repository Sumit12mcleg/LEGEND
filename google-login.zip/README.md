# Simple sample Flask App with Google Login

Name - Sumit Sharma
Email - 7mcxyz@gmail.com



